package com.mek.haberler.util;

public class Util {

    /*
    * Hürriyet Haberin isteklerinde giden api-key
    *
    * */
    public static String API_KEY = "e41c62d01ebf4cfba1f52448d53042bb";

    /*
    *
    * Hürriyet Haber Base Url
    *
    * */
    public static String BASE_URL = "https://api.hurriyet.com.tr/v1/";


}
